#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int tomb[10] = {420, 50, 201, 30, 69, 120, 12, 8, 20, 30};

    int i = 0;
    printf("A t�mb:");
    while ( i < 10) {
        printf("[%d]=" "%d ", i,  tomb[i]);
        i += 1;
    }

    int min = tomb[0];
    int minhely;

    for (i = 0; i < 10; i += 1) {
        if (tomb[i] < min)
            min = tomb[i], minhely = i;

    }

    printf("\nA legkisebb szam: ");
    printf("%d", min);
    printf("\nA legkisebb indexe: ");
    printf("%d", minhely);




    return 0;
}
