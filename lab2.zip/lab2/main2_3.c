#include <stdio.h>

int main() {
    int a = 11220;
    int b = 2002;
    while (b > 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    /*b = 44, a = 374

    */
    printf("lnko = %d\n", a);
    return 0;
}
