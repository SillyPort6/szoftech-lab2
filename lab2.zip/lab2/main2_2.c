#include <stdio.h>

int main() {
    int szorzat = 1;
    int n = 8;
    while (n > 1) {
        szorzat *= n;
        n -= 1;
    /*n=3, szorzat=6720
    vissza fel� indul el a ciklus 8t�l 1 ig
    */
    }
    printf("%d\n", szorzat);
    return 0;
}
