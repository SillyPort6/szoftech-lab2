#include <stdio.h>
#include <stdbool.h>

int main(void) {
    int tomb[10];

    for (int i = 0; i < 10; i += 1)
        tomb[i] = i * 10;

    int i = 0;
    while (true) {
        printf("%d. elem: %d\n", i, tomb[i]);
        i += 1;
    }

    return 0;
}

/* az�rt nem m�k�dik megdfelel�en, mert a while ciklusban 20-ig megy az indexel�s, m�g a t�mb csak 10 elemes. A mem�ri�ban l�v� sz�mokat adja vissza
Am�g a mem�ri�ban vannak sz�mok addig ki�rja azokat, addig fut am�g igaz r� a felt�tel
 */
